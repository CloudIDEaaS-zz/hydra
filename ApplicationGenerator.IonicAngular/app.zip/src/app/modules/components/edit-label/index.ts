export { EditLabelComponent as EditLabel } from './edit-label';
export { EditLabelModule } from './edit-label.module';
export { EditChangeArgs } from './editChangeArgs';
