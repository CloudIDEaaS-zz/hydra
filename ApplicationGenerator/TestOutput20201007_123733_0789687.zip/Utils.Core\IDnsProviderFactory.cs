namespace Utils
{
    public interface IDnsProviderFactory
    {
        IDnsProvider CreateProvider();
    }
}