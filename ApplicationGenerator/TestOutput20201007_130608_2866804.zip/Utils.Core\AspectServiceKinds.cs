namespace Utils
{
    public enum AspectServiceKinds
    {
        None,
        Logging,
        All = Logging
    }
}
