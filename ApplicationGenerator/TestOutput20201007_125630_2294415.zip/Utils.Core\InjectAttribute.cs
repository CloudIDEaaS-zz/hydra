using System;
using System.Collections.Generic;
using System.Text;

namespace Utils
{
    [AttributeUsage(AttributeTargets.Property)]
    public class InjectAttribute : Attribute
    {
    }
}
