interface Window { my: any; }

interface JQuery {
    resizeRelativeTo(parentElement : JQuery<HTMLElement>);
}

declare module jasmine {

  export interface ArrayLikeMatchers<T> {
    any(expected: (T) => boolean): boolean;
    all(expected: (T) => boolean): boolean;
  }
}
