let dataTypes = { replaceExpression: "DataTypes" };

return {
  dataTypes: dataTypes,
  slides: {
    cases: { replaceExpression: "DataTypeCases" }
  }
}